package bean;

import util.DBHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UpdateMessage {
    private Connection connection;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;

    public void updateStudent(String sql,String username,String userclass,String num) throws SQLException {
        connection = DBHelper.getConnection();

            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,username);
            preparedStatement.setString(2,userclass);
            preparedStatement.setString(3,num);
            preparedStatement.executeUpdate();
//        preparedStatement.execute();
            DBHelper.close(connection,preparedStatement,resultSet);

    }
    public void updateTeacher(String sql,String username,String num) throws SQLException {
        connection = DBHelper.getConnection();

        preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1,username);
        preparedStatement.setString(2,num);
        preparedStatement.executeUpdate();
//        preparedStatement.execute();
        DBHelper.close(connection,preparedStatement,resultSet);

    }
}
