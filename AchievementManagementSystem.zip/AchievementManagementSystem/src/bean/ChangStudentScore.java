package bean;

import entity.Student;
import util.DBHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ChangStudentScore {
//    判断学生是否存在
    public static int isStudentExit(String studentid){//返回值1表示存在，返回0表示不存在
        Connection con=null;
        PreparedStatement sql=null;
        ResultSet rs=null;
        try {
            con = DBHelper.getConnection();
            sql = con.prepareStatement("select * from student where num=?");
            sql.setString(1,studentid);
            rs = sql.executeQuery();
            if(rs.next()){
                return 1;
            }
            rs.close();
            sql.close();
            con.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return 0;
    }
//    修改学生成绩(这里的Student所含属性值：studentid和成绩数组)
    public static void changscore(Student student){
        for(int i=0;i<student.getScore().length;i++){
            Connection con=null;
            PreparedStatement sql=null;
            PreparedStatement sql2=null;
            PreparedStatement sql3=null;
            ResultSet rs=null;
            try{
                String courseid=String.valueOf(i+1);
                System.out.println("courseid======"+courseid);
                con= DBHelper.getConnection();
                sql2=con.prepareStatement("select * from coursescore where studentid=? and courseid=?");//查看成绩表是否有该条科目的成绩记录
                sql2.setString(1,student.getNum());
                sql2.setString(2,courseid);
                rs=sql2.executeQuery();
                if(rs.next()){//如果存在该科目的成绩，则执行更新操作
                    sql=con.prepareStatement("update coursescore set coursescore=? where studentid=? and courseid=?");
                    sql.setFloat(1,Float.parseFloat(student.getScore()[i]));
                    sql.setString(2,student.getNum());
                    sql.setString(3,courseid);
                    sql.executeUpdate();
                    rs.close();
                    sql.close();
                }else{//如果不存在该科目的成绩，则执行插入操作
                    System.out.println("studentid="+student.getNum()+"courseid="+courseid+"score="+Float.parseFloat(student.getScore()[i]));
                    sql3=con.prepareStatement("insert into coursescore (studentid,courseid,coursescore) values (?,?,?)");
                    sql3.setString(1,student.getNum());
                    sql3.setString(2,courseid);
                    sql3.setFloat(3,Float.parseFloat(student.getScore()[i]));
                    sql3.executeUpdate();
                    sql3.close();
                }
                sql2.close();
                con.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
