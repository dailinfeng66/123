package bean;

import util.DBHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class getCourseByTeacherId  {
    private Connection connection;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;

    public String getCourseId(String teacherid) throws SQLException {
        String courseid="";
        connection = DBHelper.getConnection();
        String sql = "select * from course where teacherid = ?";
        preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1,teacherid);
        resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            courseid = resultSet.getString("courseid");
        }
        DBHelper.close(connection,preparedStatement,resultSet);




        return courseid;
    }



}
