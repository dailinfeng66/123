package bean;

import entity.Course;
import entity.Student;
import util.DBHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

public class GetAllscore {

//    通过学生数据表获得所有的学生id
    public static List<String> getAllStudentId(){
        List<String> studentsid=new ArrayList<String>();

        Connection con=null;
        PreparedStatement sql=null;
        ResultSet rs=null;
        try{
            con= DBHelper.getConnection();
            sql=con.prepareStatement("select * from student");
            rs=sql.executeQuery();
            while(rs.next()){
                studentsid.add(rs.getString("num"));
            }
            rs.close();
            sql.close();
            con.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return studentsid;
    }


//    通过id获得某学生的实体对象（不包含成绩）
    public static Student getStudentById(String studentid){
        Student student=new Student();
        Connection con=null;
        PreparedStatement sql=null;
        ResultSet rs=null;
        try{
            con= DBHelper.getConnection();
            sql=con.prepareStatement("select * from student where num=?");
            sql.setString(1,studentid);
            rs=sql.executeQuery();
            if(rs.next()){
                student.setNum(studentid);
                student.setName(rs.getString("name"));
                student.setClassname(rs.getString("class"));
            }
            rs.close();
            sql.close();
            con.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return student;
    }


//    通过课程id获得课程实体类(不包含课程班级)
    public static Course getCourseById(String courseid){
        Course course=new Course();

        Connection con=null;
        PreparedStatement sql=null;
        ResultSet rs=null;
        try{
            con= DBHelper.getConnection();
            sql=con.prepareStatement("select * from course where courseid=?");
            sql.setString(1,courseid);
            rs=sql.executeQuery();
            if(rs.next()){
                course.setCourseid(courseid);
                course.setCoursename(rs.getString("coursename"));
            }
            rs.close();
            sql.close();
            con.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return course;
    }


//    通过学生id查找该学生的所有成绩（此处返回的是按课程id序号排序的成绩字符串集合）
//    public static List<String> getAllScoreById(String studentid){
//    List<String> scores=new ArrayList<String>();
//    Connection con=null;
//    PreparedStatement sql=null;
//    ResultSet rs=null;
//    try{
//        con= DBHelper.getConnection();
//        sql=con.prepareStatement("select * from coursescore where studentid=? order by courseid asc");
//        sql.setString(1,studentid);
//        rs=sql.executeQuery();
//        while(rs.next()){
//                int scoreflag=Integer.parseInt(rs.getString("courseid"));//获取课程id，方便找到插入成绩的位置
//                if(scoreflag!=0){
//
//                }
//                scores.add(scoreflag-1,rs.getString("coursescore"));
//        }
//        System.out.println(scores);
//        rs.close();
//        sql.close();
//        con.close();
//    }catch (Exception e){
//        e.printStackTrace();
//    }
//    return scores;
//}
public static String[] getAllScoreById(String studentid){
    String scores[]={"0","0","0","0"};
    Connection con=null;
    PreparedStatement sql=null;
    ResultSet rs=null;
    try{
        con= DBHelper.getConnection();
        sql=con.prepareStatement("select * from coursescore where studentid=? order by courseid asc");
        sql.setString(1,studentid);
        rs=sql.executeQuery();
        while(rs.next()){
            int scoreflag=Integer.parseInt(rs.getString("courseid"));//获取课程id，方便找到插入成绩的位置
            scores[scoreflag-1]=rs.getString("coursescore");
        }
        System.out.println(scores);
        rs.close();
        sql.close();
        con.close();
    }catch (Exception e){
        e.printStackTrace();
    }
    return scores;
}

//测试主函数
//    public static void main(String args[]){

//        List<String> studentsid=GetAllscore.getAllStudentId();
//        for(String studentid : studentsid) {
//            System.out.println(studentid);
//        }

//
//        Student student=GetAllscore.getStudentById("1");
//        System.out.println(student);

//          Course course=GetAllscore.getCourseById("1");
//          System.out.println(course);

//        List<String> scores=GetAllscore.getAllScoreById("1");
//        for(String score : scores) {
//            System.out.println(score);
//        }
//    }
}
