package bean;

import entity.Student;
import entity.Teacher;
import util.DBHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class getPeopleList {
    private Connection connection;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;

    public List<Student> getStudentList(){
        List<Student> list = new ArrayList<>();
        connection = DBHelper.getConnection();
        String sql = "select * from student ";
        try {
            preparedStatement = connection.prepareStatement(sql);
            resultSet=preparedStatement.executeQuery();
            while (resultSet.next()){
                Student student = new Student();
                student.setNum(resultSet.getString("num"));
                student.setName(resultSet.getString("name"));
                student.setClassname(resultSet.getString("class"));
                list.add(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        DBHelper.close(connection,preparedStatement,resultSet);
        return list;
    }

    public List<Teacher> getTeacherList(){
        List<Teacher> list = new ArrayList<>();
        connection = DBHelper.getConnection();
        String sql = "select * from teacher ";
        try {
            preparedStatement = connection.prepareStatement(sql);
            resultSet=preparedStatement.executeQuery();
            while (resultSet.next()){
                Teacher teacher = new Teacher();
                teacher.setNum(resultSet.getString("num"));
                teacher.setName(resultSet.getString("name"));
                list.add(teacher);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        DBHelper.close(connection,preparedStatement,resultSet);
        return list;
    }
}
