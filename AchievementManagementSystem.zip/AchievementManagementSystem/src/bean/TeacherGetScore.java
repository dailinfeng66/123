package bean;


import entity.Course;
import entity.Student;
import util.DBHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class TeacherGetScore {


    //通过教师id获取所授课程实体类,其中包含多个班级
    public static Course getCourseByTeacherId(String teacherid){
        Connection con=null;
        PreparedStatement sql=null;
        ResultSet rs=null;
        Course course=new Course();
        List<String> classname=new ArrayList<String>();
        try{
            con= DBHelper.getConnection();
            sql=con.prepareStatement("select * from course where teacherid=?");
            sql.setString(1,teacherid);
            rs=sql.executeQuery();
            while(rs.next()){
                course.setCourseid(rs.getString("courseid"));
                course.setCoursename(rs.getString("coursename"));
                course.setTeacherid(rs.getString("teacherid"));
                classname.add(rs.getString("class"));
            }
            course.setClassname(classname);
            System.out.println("one course more class"+course.getClassname().get(0)+"**"+course.getClassname().get(1));
            rs.close();
            sql.close();
            con.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return course;
    }

    //通过班级名称获取该班级所有的学生实体对象集合(此处不包含学生的成绩)
    public static List<Student> getAllStudentByClassname(String classname){
        System.out.println("中文乱不乱码");
        System.out.println("parameter:classname="+classname);
        Connection con=null;
        PreparedStatement sql=null;
        ResultSet rs=null;
        List<Student> students=new ArrayList<Student>();
        try{
            con= DBHelper.getConnection();
            sql=con.prepareStatement("select * from student where class=?");
            sql.setString(1,classname);
            rs=sql.executeQuery();
            while(rs.next()){
                System.out.println("rs not null");
                Student student=new Student();
                student.setNum(rs.getString("num"));
                student.setName(rs.getString("name"));
                student.setClassname(rs.getString("class"));
                System.out.println("onestudent="+student);
                students.add(student);
            }
            rs.close();
            sql.close();
            con.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return students;
    }

    //通过一个班的学生集合和某课程id获得新的学生实体对象集合(此处包含学生的成绩)
    public static List<Student> getAllStudentScoreByStudentId(List<Student> students,String courseid){
        Connection con=null;
        PreparedStatement sql=null;
        ResultSet rs=null;
        List<Student> newstudents=new ArrayList<Student>();
        try{
            con= DBHelper.getConnection();
            for(int i=0;i<students.size();i++){
                Student student=new Student();
                String studentid=students.get(i).getNum();
                sql=con.prepareStatement("select * from coursescore where studentid=? and courseid=?");
                sql.setString(1,studentid);
                sql.setString(2,courseid);
                rs=sql.executeQuery();
                if(rs.next()){
                    student.setNum(studentid);
                    student.setName(students.get(i).getName());
                    student.setClassname(students.get(i).getClassname());
                    String scores[]={"0","0","0","0"};
                    scores[0]=rs.getString("coursescore");
                    student.setScore(scores);
                    newstudents.add(student);
                }else{
                    student.setNum(studentid);
                    student.setName(students.get(i).getName());
                    student.setClassname(students.get(i).getClassname());
                    String scores[]={"0","0","0","0"};
                    scores[0]="0";
                    student.setScore(scores);
                    newstudents.add(student);
                }
            }
//            DBHelper.close(con,sql,rs);
            rs.close();
            sql.close();
            con.close();
        }catch (Exception e){
            e.printStackTrace();
        }
        return newstudents;
    }
}
