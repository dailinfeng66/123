package bean;

import entity.Student;
import util.DBHelper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class InsertStudentScore {
    //获得所有成绩不全的学生
    public static List<Student> getBrokenStudent(){
        List<Student> brokenStudent=new ArrayList<Student>();
        List<String> studentsid= GetAllscore.getAllStudentId();//获取所有学生的id
        int flag=0;//1表示分数里有空的，0表示没有空的
        for(int i=0;i<studentsid.size();i++){
            flag=0;
            Student onestudent=GetAllscore.getStudentById(studentsid.get(i));//通过学生id获取学生实体对象
            onestudent.setNum(studentsid.get(i));
            String[] score=GetAllscore.getAllScoreById(studentsid.get(i));//获取单个学生的成绩
            for(int j=0;j<score.length;j++){
                if(score[j].equals("0")||score[j].equals("")){
                    flag=1;
                }
            }
            if(flag==1){
                onestudent.setScore(score);
                brokenStudent.add(onestudent);
            }
        }
        System.out.println("brokenStudent="+brokenStudent);
        return brokenStudent;
    }
}
