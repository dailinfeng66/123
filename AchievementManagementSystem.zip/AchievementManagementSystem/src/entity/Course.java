package entity;

import java.util.List;

public class Course {
    private String courseid;
    private String coursename;
    private String teacherid;
    private List<String> classname;

    public List<String> getClassname() {
        return classname;
    }

    public void setClassname(List<String> classname) {
        this.classname = classname;
    }

    public String getCourseid() {
        return courseid;
    }

    public void setCourseid(String courseid) {
        this.courseid = courseid;
    }

    public String getCoursename() {
        return coursename;
    }

    public void setCoursename(String coursename) {
        this.coursename = coursename;
    }

    public String getTeacherid() {
        return teacherid;
    }

    public void setTeacherid(String teacherid) {
        this.teacherid = teacherid;
    }
}
