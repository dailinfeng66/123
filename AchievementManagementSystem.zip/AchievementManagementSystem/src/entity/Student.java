package entity;

import java.util.List;

public class Student {

    private String num;
    private String name;
    private String password;
    private String classname;
//    private List<String> score;
    private String score[] = {"0,0,0,0"};
    private Float totalscore;

    public Float getTotalscore() {
        return totalscore;
    }

    public void setTotalscore(Float totalscore) {
        this.totalscore = totalscore;
    }

    public String[] getScore() {
        return score;
    }

    public void setScore(String[] score) {
        this.score = score;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    @Override
    public String toString() {
        return "Student{" +
                "num='" + num + '\'' +
                ", name='" + name + '\'' +
                ", password='" + password + '\'' +
                ", classname='" + classname + '\'' +
                ", score=" + score + '\'' +
                ", totalscore='" + totalscore + '\'' +
                '}'+"\n";
    }
}
