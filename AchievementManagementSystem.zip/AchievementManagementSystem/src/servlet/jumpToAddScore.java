package servlet;

import bean.ChangStudentScore;
import bean.GetAllscore;
import bean.InsertStudentScore;
import entity.Student;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class jumpToAddScore extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        String type=request.getParameter("type");
        if(type!=null){
            //查看成绩不完全的学生
            if(type.equals("seebrokenstudent")){
                List<Student> brokenStudent= InsertStudentScore.getBrokenStudent();
                request.getSession().setAttribute("brokenStudent",brokenStudent);
                request.getSession().setAttribute("innerpage","addScore.jsp");
                response.sendRedirect(request.getContextPath()+"/indexteacher.jsp");
            }
            //查看该名学生的成绩
            if(type.equals("see")){
                String studentid=request.getParameter("studentid");
                String score[]= GetAllscore.getAllScoreById(studentid);
                Student student=new Student();
                student.setNum(studentid);
                student.setScore(score);
                request.getSession().setAttribute("studentscore",student);
                response.sendRedirect(request.getContextPath()+"/addScore.jsp");

            }
            //修改该学生的成绩
            if(type.equals("doinsertscore")){
                Student student=new Student();
                student.setNum(request.getParameter("num"));
                String []score=new String[4];
                score[0]=request.getParameter("chinese");
                score[1]=request.getParameter("math");
                score[2]=request.getParameter("english");
                score[3]=request.getParameter("music");
                student.setScore(score);
                ChangStudentScore.changscore(student);
                request.getSession().setAttribute("studentscore",student);
                response.sendRedirect(request.getContextPath()+"/addScore.jsp");
            }
        }




    }
}
