package servlet;

import entity.Student;
import entity.Teacher;
import util.DBHelper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet(name = "ServletDologin")
public class ServletDologin extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        session.setAttribute("innerpage","welcome.jsp");
        String type=request.getParameter("type");
        System.out.println("type="+type);
        String registertType=request.getParameter("registerType");
        System.out.println("registertType="+registertType);
        session.setAttribute("handlestudent",0);

        if(type!=null){
            //处理登录请求，此处为学生登录
            if (type.equals("student")) {
                String num=request.getParameter("username");
                String password=request.getParameter("p");
                System.out.println("num="+num+"password="+password+"type="+type);
                Connection con=null;
                PreparedStatement sql=null;
                ResultSet rs=null;
                Student one=new Student();
                int loginstates;
                try{
                    con= DBHelper.getConnection();
                    sql=con.prepareStatement("select * from student where num=?");
                    sql.setString(1,num);
                    rs=sql.executeQuery();
                    if(rs.next()){
                        if(rs.getString("password").equals(password)){
                            one.setNum(rs.getString("num"));
                            one.setName(rs.getString("name"));
                            one.setClassname(rs.getString("class"));
                            loginstates=1;   //密码输入成功
                            request.getSession().setAttribute("student",one);
                        }else {
                            loginstates = 0;   //密码输入错误

                        }
                    }else{
                        loginstates=-1;  //用户不存在
                    }
                    rs.close();
                    sql.close();
                    con.close();
                    System.out.println("states="+loginstates);
                    session.setAttribute("judge","student");
                    session.setAttribute("num",num);
                    request.getRequestDispatcher("studentLogin.jsp?loginstates="+loginstates).forward(request,response);
                }catch (Exception e){
                    e.printStackTrace();
                }

            }


            //处理登录请求，此处为教师登录
            if (type.equals("teacher")) {
                String num=request.getParameter("username");
                String password=request.getParameter("p");
                System.out.println("num="+num+"password="+password+"type="+type);
                Connection con=null;
                PreparedStatement sql=null;
                ResultSet rs=null;
                Teacher one=new Teacher();
                int loginstates;
                try{
                    con= DBHelper.getConnection();
                    sql=con.prepareStatement("select * from teacher where num=?");
                    sql.setString(1,num);
                    rs=sql.executeQuery();
                    if(rs.next()){
                        if(rs.getString("password").equals(password)){
                            one.setNum(rs.getString("num"));
                            one.setName(rs.getString("name"));
                            loginstates=1;   //密码输入成功
                            request.getSession().setAttribute("teacher",one);
                        }else {
                            loginstates = 0;   //密码输入错误
                        }
                    }else{
                        loginstates=-1;  //用户不存在
                    }
                    rs.close();
                    sql.close();
                    con.close();
                    System.out.println("states="+loginstates);
                    session.setAttribute("judge","teacher");
                    session.setAttribute("num",num);
                    request.getRequestDispatcher("teacherLogin.jsp?loginstates="+loginstates).forward(request,response);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }

        }

        if(registertType!=null){
            //处理注册请求，此处为学生注册
            if(registertType.equals("student")){
                String num=request.getParameter("user");
                String password=request.getParameter("passwd");
                System.out.println("num="+num+"password="+password+"registertType="+registertType);
                Connection con=null;
                PreparedStatement sql=null;
                PreparedStatement sql2=null;
                ResultSet rs=null;
                int registerStates;
                try{
                    con= DBHelper.getConnection();
                    sql=con.prepareStatement("select * from student where num=?");
                    sql.setString(1,num);
                    rs=sql.executeQuery();
                    if(rs.next()){
                        registerStates=-1;      //表示该账号已经被注册
                    }else{
                        sql2=con.prepareStatement("insert into student(num,password) values(?,?)");
                        sql2.setString(1,num);
                        sql2.setString(2,password);
                        sql2.executeUpdate();
                        registerStates=1;  //新用户注册成功
                    }
                    rs.close();
                    sql.close();
                    con.close();
                    System.out.println("registerStates="+registerStates);
                    request.getRequestDispatcher("studentLogin.jsp?registerStates="+registerStates).forward(request,response);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }

            //处理注册请求，此处为教师注册
            if(registertType.equals("teacher")){
                String num=request.getParameter("user");
                String password=request.getParameter("passwd");
                System.out.println("num="+num+"password="+password+"registertType="+registertType);
                Connection con=null;
                PreparedStatement sql=null;
                PreparedStatement sql2=null;
                ResultSet rs=null;
                Teacher one=new Teacher();
                int registerStates;
                try{
                    con= DBHelper.getConnection();
                    sql=con.prepareStatement("select * from teacher where num=?");
                    sql.setString(1,num);
                    rs=sql.executeQuery();
                    if(rs.next()){
                        registerStates=-1;      //表示该账号已经被注册
                    }else{
                        sql2=con.prepareStatement("insert into teacher(num,password) values(?,?)");
                        sql2.setString(1,num);
                        sql2.setString(2,password);
                        sql2.executeUpdate();
                        registerStates=1;  //新用户注册成功
                    }
                    rs.close();
                    sql.close();
                    con.close();
                    System.out.println("registerStates="+registerStates);
                    request.getRequestDispatcher("teacherLogin.jsp?registerStates="+registerStates).forward(request,response);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }

        }



    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
