package servlet;

import bean.getCourseByTeacherId;
import util.DBHelper;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class addCourse extends HttpServlet {
    private Connection connection;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /**
         * 添加课程
         */


        int status = 0;
        HttpSession session = request.getSession();
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        String homework = request.getParameter("homework");
        String teacherid = (String) session.getAttribute("num");
        Date date = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd :hh:mm:ss");
        String data =  dateFormat.format(date);
        String courseid=null;
        try {
             courseid = new getCourseByTeacherId().getCourseId(teacherid);
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("getcourseIDByteacherID Error!");
        }


        connection = DBHelper.getConnection();
        String sql = "insert into homework (courseid,content,date) values (?,?,?)";
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, courseid);
            preparedStatement.setString(2, homework);
            preparedStatement.setString(3, data);
            preparedStatement.executeUpdate();
            DBHelper.close(connection, preparedStatement, resultSet);
        } catch (SQLException e) {
//            e.printStackTrace();
            status = 2;//表示添加失败!
            System.out.println("addHomework error!!!");
        }
        if (status != 2) {
            status = 1;
        }
        session.setAttribute("handlestudent", status);  //添加状态码!
        response.sendRedirect(request.getContextPath() + "/welcome.jsp");
    }
}
