package servlet;

import bean.GetAllscore;
import entity.Student;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import static java.lang.Float.parseFloat;

@WebServlet(name = "ServletAllScore")
public class ServletAllScore extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        List<Student> allstudentscore=new ArrayList<Student>();
        List<String> studentsid= GetAllscore.getAllStudentId();
        for(String studentid : studentsid) {
//            System.out.println(studentsid);
            Student onestudent=GetAllscore.getStudentById(studentid);
//            System.out.println(onestudent);
            String scores[]=GetAllscore.getAllScoreById(studentid);
            onestudent.setScore(scores);//向学生实体对象设置所有课的成绩
            Float totalscore=0f;
            for(int i=0;i<scores.length;i++){
                totalscore+= parseFloat(scores[i]);
            }
            onestudent.setTotalscore(totalscore);
//            System.out.println(onestudent);
            allstudentscore.add(onestudent);
        }           //此处得到的List集合未对成绩进行排序
        System.out.println(allstudentscore);
        Collections.sort(allstudentscore, new Comparator<Student>() {
            @Override
            public int compare(Student o1, Student o2) {
                int flag=o2.getTotalscore().compareTo(o1.getTotalscore());
                return flag;
            }
        });
        System.out.println(allstudentscore);

        request.getSession().setAttribute("allstudentscore",allstudentscore);
        request.getSession().setAttribute("innerpage","allstudentscore.jsp");

        String judge = (String) request.getSession().getAttribute("judge");
        if(judge!=null){
            if(judge.equals("teacher")){
                response.sendRedirect(request.getContextPath()+"/indexteacher.jsp");   //重定向到主页
            }else{
                response.sendRedirect(request.getContextPath()+"/indexstudent.jsp");   //重定向到主页
            }
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
