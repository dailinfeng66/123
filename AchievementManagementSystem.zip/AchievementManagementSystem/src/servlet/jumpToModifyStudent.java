package servlet;

import entity.Student;
import util.DBHelper;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class jumpToModifyStudent extends HttpServlet {
    private Connection connection;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /**
         *
         */
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        String num = request.getParameter("num");
        Student student = new Student();
    connection = DBHelper.getConnection();
    String sql = "select * from student where num = ?";
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,num);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                student.setNum(resultSet.getString("num"));
                student.setName(resultSet.getString("name"));
                student.setClassname(resultSet.getString("class"));
            }
            DBHelper.close(connection,preparedStatement,resultSet);
            request.getSession().setAttribute("studentmessage",student);


        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Modify Error!!!");
        }

       response.sendRedirect(request.getContextPath()+"/modifyStudent.jsp");
    }
}
