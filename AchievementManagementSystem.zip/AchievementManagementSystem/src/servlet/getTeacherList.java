package servlet;

import bean.getPeopleList;
import entity.Student;
import entity.Teacher;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

public class getTeacherList extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /**
         * 从数据库查询教师列表并渲染到teacherList.jsp里面并且session的innerpage设置为teacherList.jsp
         *
         */
        List<Teacher> list;
        getPeopleList getPeopleList = new getPeopleList();
        list = getPeopleList.getTeacherList();
        HttpSession session = request.getSession();
        session.setAttribute("teacherlist",list);
        session.setAttribute("innerpage","teacherList.jsp");
        System.out.println("****************************"+list);
        String judge = (String) request.getSession().getAttribute("judge");
        if(judge.equals("teacher")){
            response.sendRedirect(request.getContextPath()+"/indexteacher.jsp");   //重定向到主页
        }else{
            response.sendRedirect(request.getContextPath()+"/indexstudent.jsp");   //重定向到主页
        }
    }
}
