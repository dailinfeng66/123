package servlet;

import util.DBHelper;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class addStudent extends HttpServlet {
    private Connection connection;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /**
         * 添加学生操作
         * 添加的学生密码就是他的学号
         */
        int status = 0;
        HttpSession session = request.getSession();
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        String num = request.getParameter("num");
        String name = request.getParameter("name");
        String stuclass  =request.getParameter("stuclass");
        connection = DBHelper.getConnection();
        String sql = "insert into student (num,name,password,class) values (?,?,?,?)";
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,num);
            preparedStatement.setString(2,name);
            preparedStatement.setString(3,num);
            preparedStatement.setString(4,stuclass);
            preparedStatement.executeUpdate();
            DBHelper.close(connection,preparedStatement,resultSet);
        } catch (SQLException e) {
//            e.printStackTrace();
            status = 2 ;//表示添加学生失败!
            System.out.println("addstudent error!!!");

        }
        if(status != 2){
            status = 1;
        }
        session.setAttribute("handlestudent",status);  //添加状态码!
        response.sendRedirect(request.getContextPath()+"/welcome.jsp");
    }
}
