package servlet;

import bean.getPeopleList;
import entity.Student;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

public class getStudentList extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /**
         * 查询学生信息列表并渲染在studentList.jsp上面
         * 然后把这个jsp名字放在session的innerpage里面
         */

        List<Student> list;
        getPeopleList getPeopleList = new getPeopleList();
        list = getPeopleList.getStudentList();
        HttpSession session = request.getSession();
        session.setAttribute("studentlist",list);
//        session.setAttribute("innerpage","studentList.jsp");
        session.setAttribute("innerpage","studentList.jsp");
        System.out.println("****************************"+list);
        String judge = (String) session.getAttribute("judge");
        if(judge.equals("teacher")){
            response.sendRedirect(request.getContextPath()+"/indexteacher.jsp");   //重定向到主页
        }else{
            response.sendRedirect(request.getContextPath()+"/indexstudent.jsp");   //重定向到主页
        }

    }
}
