package servlet;

import util.DBHelper;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class modifyStudent extends HttpServlet {
    private Connection connection;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /**
         * 修改学生操作
         * 从数据库读取指定学生的数据,然后显示到前端页面,前端页面修改以后提交   写入数据库
         */
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        String num = request.getParameter("num");
        String name = request.getParameter("name");
        String stuclass = request.getParameter("stuclass");

        connection = DBHelper.getConnection();
        String sql = "update student set class = ?,name = ? where num = ?";
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, stuclass);
            preparedStatement.setString(2, name);
            preparedStatement.setString(3, num);
            preparedStatement.executeUpdate();
            DBHelper.close(connection,preparedStatement,resultSet);
            request.getSession().setAttribute("handlestudent",7);
response.sendRedirect(request.getContextPath()+"/welcome.jsp");
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }
}
