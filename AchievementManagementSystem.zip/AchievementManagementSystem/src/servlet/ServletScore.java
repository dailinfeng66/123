package servlet;

import bean.TeacherGetScore;
import entity.Course;
import entity.Student;
import util.DBHelper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

@WebServlet(name = "ServletScore")
public class ServletScore extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        String num=(String)request.getSession().getAttribute("num");//老师账号
        String type=request.getParameter("type");//老师成绩操作类型
        if(type!=null){
            //处理老师查看成绩的请求,可显示老师所授的班级
            if(type.equals("look")){
                System.out.println("多次请求");
                Course course=TeacherGetScore.getCourseByTeacherId(num);//通过教师id获取所授课程实体类,其中包含多个班级名称
                request.getSession().setAttribute("course",course);
                request.getSession().setAttribute("innerpage","studentscore.jsp");
                response.sendRedirect(request.getContextPath()+"/indexteacher.jsp");
            }
            //处理查看某一班级的成绩请求
            if(type.equals("lookclass")){

//                String classname1=request.getParameter("classname");
//                String classname = new String(classname1.getBytes("ISO8859-1"), "UTF-8");
                String classname=request.getParameter("classname");
                System.out.println("*****classname="+classname);
                if(classname!=null){
                    List<Student> students=TeacherGetScore.getAllStudentByClassname(classname);//通过班级名称获取该班级所有的学生实体对象集合(此处不包含学生的成绩)
                    System.out.println("*****students"+students);
                    Course course=(Course)request.getSession().getAttribute("course");//获取session中的course
                    String courseid=course.getCourseid();
                    System.out.println("*****courseid="+courseid);
                    List<Student> newstudents=TeacherGetScore.getAllStudentScoreByStudentId(students,courseid);
                    System.out.println("*****newstudents"+newstudents);
                    request.getSession().setAttribute("newstudents",newstudents);
                    response.sendRedirect(request.getContextPath()+"/studentscore.jsp");   //重定向到主页
                }
            }
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
