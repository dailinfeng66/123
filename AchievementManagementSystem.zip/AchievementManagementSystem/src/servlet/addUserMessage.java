package servlet;

import bean.UpdateMessage;
import util.DBHelper;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class addUserMessage extends HttpServlet {
    private Connection connection;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /**
         * 通过ajax向服务器上传回来学生的信息
         */
        response.setContentType("text/html;charset=UTF-8");
        response.setHeader("Access-Control-Allow-Origin","*");   //ajax用的

        String username = request.getParameter("name");
        String userclass = request.getParameter("class");
        String num = (String) request.getSession().getAttribute("num");
        String judge = (String) request.getSession().getAttribute("judge");
        PrintWriter out = null;
        try {
            out = response.getWriter();
        } catch (IOException e2) {
            e2.printStackTrace();
        }


        if(judge.equals("student")){  //表示此时是学生在完善信息
            String sql = "update student set name = ? , class = ? where num = ?";
            try {
                new UpdateMessage().updateStudent(sql,username,userclass,num);
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println(" database error");
                out.print("fail");
            }
            out.print("success");//向前端返回操作成功
        }else if(judge.equals("teacher")){  //表示此时是老师在完善信息
            String sql = "update teacher set name = ? where num = ?";
            try {
                new UpdateMessage().updateTeacher(sql,username,num);
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("database error");
                out.print("fail");
            }
            out.print("success"); //向前端返回操作成功
        }
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req,resp);
    }
}
