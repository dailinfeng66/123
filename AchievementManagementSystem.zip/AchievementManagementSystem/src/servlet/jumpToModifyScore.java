package servlet;

import bean.ChangStudentScore;
import bean.GetAllscore;
import entity.Student;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class jumpToModifyScore extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /**
         * 在这个地方   读取出学生原来的成绩并显示到前端页面上
         *   然后提交之后   把修改过的信息提交到服务器 再update
         *   读取 包括 学生学号  也放到一个hidden的input里面  这个hidden的input我没做
         *
         */

        String type=request.getParameter("type");
        //初次加载成绩修改页面
        if(type.equals("changescore")){
            request.getSession().setAttribute("innerpage","modifyScore.jsp");
            response.sendRedirect(request.getContextPath()+"/indexteacher.jsp");
        }
        //查看某学生的成绩
        if(type.equals("see")){
            String studentid=request.getParameter("studentid");
            int isexit=ChangStudentScore.isStudentExit(studentid);
            if(isexit==1){
                String score[]=GetAllscore.getAllScoreById(studentid);
                Student student=new Student();
                student.setNum(studentid);
                student.setScore(score);
                request.getSession().setAttribute("isexit","exit");
                request.getSession().setAttribute("studentscore",student);
                response.sendRedirect(request.getContextPath()+"/modifyScore.jsp");
            }else {
                request.getSession().setAttribute("isexit","noexit");
                response.sendRedirect(request.getContextPath()+"/modifyScore.jsp");
            }

        }
        //修改该学生的成绩
        if(type.equals("dochangescore")){
            Student student=new Student();
            student.setNum(request.getParameter("num"));
            String []score=new String[4];
            score[0]=request.getParameter("chinese");
            score[1]=request.getParameter("math");
            score[2]=request.getParameter("english");
            score[3]=request.getParameter("music");
            student.setScore(score);
            ChangStudentScore.changscore(student);
            request.getSession().setAttribute("studentscore",student);
            response.sendRedirect(request.getContextPath()+"/modifyScore.jsp");

        }
    }
}
