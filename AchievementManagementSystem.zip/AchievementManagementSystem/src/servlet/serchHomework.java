package servlet;

import entity.homework;
import util.DBHelper;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class serchHomework extends HttpServlet {
    private Connection connection;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /**
         * 查询作业
         */
        List<homework> homework = new ArrayList<>();
        connection = DBHelper.getConnection();
        String sql="select * from homework";
        try {
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                homework homework1 = new homework();
                homework1.setContent(resultSet.getString("content"));
                homework1.setDate(resultSet.getString("date"));
                String courseid = resultSet.getString("courseid");
                if(courseid.equals("1")){
                    homework1.setCourseid("语文");
                }else if(courseid.equals("2")){
                    homework1.setCourseid("数学");
                }else if(courseid.equals("3")){
                    homework1.setCourseid("英语");
                }else if (courseid.equals("4")){
                    homework1.setCourseid("音乐");
                }
                homework.add(homework1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Serch Homerk Error!");
        }
        request.getSession().setAttribute("innerpage","homeworkList.jsp");
        request.getSession().setAttribute("homeworkList",homework);
        String judge = (String) request.getSession().getAttribute("judge");
        if(judge.equals("teacher")){
            response.sendRedirect(request.getContextPath()+"/indexteacher.jsp");   //重定向到主页
        }else{
            response.sendRedirect(request.getContextPath()+"/indexstudent.jsp");   //重定向到主页
        }


    }
}
