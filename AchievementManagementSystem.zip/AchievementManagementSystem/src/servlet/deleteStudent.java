package servlet;

import util.DBHelper;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class deleteStudent extends HttpServlet {
    private Connection connection;
    private ResultSet resultSet;
    private PreparedStatement preparedStatement;
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /**
         * 处理删除学生操作
         */
    int status = 0;
        String num = request.getParameter("num");
        connection = DBHelper.getConnection();
        String sql = "delete from student where num = ?";
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1,num);
            preparedStatement.executeUpdate();
            DBHelper.close(connection,preparedStatement,resultSet);
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("delete student Error!!!");
            status = 6;
        }
        if(status != 6){
            status =5;
        }
        request.getSession().setAttribute("handlestudent",status); //添加状态码
        response.sendRedirect(request.getContextPath()+"/welcome.jsp"); //返回主页面
    }
}
