package util;

import java.sql.*;

public class DBHelper {
    private static final String url="jdbc:mysql://localhost:3306/ams?useSSL=false&useUnicode=true&characterEncoding=UTF-8";
    private static Connection con=null;
    static{
        try{
            Class.forName("com.mysql.jdbc.Driver");//加载驱动程序
        }catch (Exception e){
            e.printStackTrace();
            System.out.print("加载驱动程序出错!");
        }
    }
	public static Connection getConnection()  {
        try {
            if(con==null||con.isClosed()){
                try{
con=DriverManager.getConnection(url,"root","123123");//创建连接
return con;
}catch (Exception e){
                    e.getStackTrace();
}
}
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return con;
    }

    public static void close(Connection conn, Statement stmt, ResultSet rs){
        try {
            if(rs!=null &&!rs.isClosed()){
                rs.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            if(stmt!=null &&!stmt.isClosed()){
                stmt.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            if(conn!=null &&!conn.isClosed()){
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
